import { createManifest,rebuildRoundManifest } from './reward-allocation.mjs';
export function auditManifest(m){
 if(!m||m.chainId!==46630||!Array.isArray(m.allocations)||m.allocations.length>5000||!/^0x[a-f0-9]{40}$/i.test(m.distributor||''))throw Error('Invalid testnet manifest');
 const rebuilt=m.version===2?rebuildRoundManifest(m):createManifest(m.epoch,BigInt(m.budget),m.distributor,m.allocations.map(a=>({address:a.address,points:a.points}))); 
 // Ignore operator metadata such as state/snapshot while checking every canonical allocation field.
 for(const key of Object.keys(rebuilt))if(JSON.stringify(m[key])!==JSON.stringify(rebuilt[key]))throw Error('Allocation mismatch: '+key);
 return {valid:true,chainId:46630,epoch:m.epoch,root:m.root,budget:m.budget,totalWork:m.totalWork??m.totalPoints,recipients:m.allocations.length,scope:'Checks deterministic allocation, Merkle root and every proof. Does not attest to underlying mining or onchain funding.'};
}
