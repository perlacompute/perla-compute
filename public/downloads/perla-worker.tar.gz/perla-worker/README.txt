Perla worker adapter 0.1
Read the website installation guide before running setup-worker.sh.
Supported upstream profile: Linux, NVIDIA sm90 (H100/H200), dense rank-128 certificate v3.
Download your worker.env from the signed-in dashboard. No private wallet key is needed.
GPU validation and operator activation are separate from software installation.
